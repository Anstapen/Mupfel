#include "DebugLayer.h"
#include "Core/Application.h"
#include "Renderer/Rectangle.h"
#include "Renderer/Circle.h"
#include "Renderer/Text.h"
#include "Renderer/Texture.h"
#include <string>
#include <format>
#include "ECS/Registry.h"
#include "ECS/View.h"
#include "ECS/Components/Collider.h"
#include "ECS/Components/Transform.h"
#include "ECS/Components/Movement.h"
#include "Core/Profiler.h"
//#include "raylib.h"



#define RAYGUI_IMPLEMENTATION
#include "raygui.h"

void Mupfel::DebugLayer::OnInit()
{
}

void Mupfel::DebugLayer::OnUpdate(double timestep)
{
	if (single_stepping && IsKeyPressed(KEY_SPACE))
	{
		Application::PhysicsStep();
	}
}

void Mupfel::DebugLayer::OnRender()
{
	DrawDebugGUI();
	DrawDebugInfo();

	if (show_grid)
	{
		DrawCollisionGrid();
	}

	if (show_collider) {
		DrawEntityColliders();
	}

	if (show_velocity)
	{
		DrawEntityVelocity();
	}

	if (show_entity_index)
	{
		DrawEntityIndex();
	}

	if (show_perf)
	{
		DrawPerformanceMetrics();
	}
	
}

static float slider_val = 0.0f;

void Mupfel::DebugLayer::DrawDebugInfo()
{
	uint32_t current_entities = Mupfel::Application::GetCurrentRegistry().GetCurrentEntities();
	/* Get the time of the last frame. */
	float last_frame_time = Mupfel::Application::GetLastFrameTime();
	float fps = 1.0f / last_frame_time;

	int screen_height = Mupfel::Application::GetCurrentRenderHeight();
	int screen_width = Mupfel::Application::GetCurrentRenderWidth();

	std::string text1 = std::vformat("FPS: {:.1f}", std::make_format_args(fps));
	std::string text2 = std::vformat("Entities(GLOBAL): {}", std::make_format_args(current_entities));
	Text::RaylibDrawText(text1.c_str(), 10, 20);
	Text::RaylibDrawText(text2.c_str(), 10, 40);
}

void Mupfel::DebugLayer::DrawCollisionGrid()
{
	/* Lets render the Collision Grid */
	uint32_t screen_width = Mupfel::Application::GetCurrentRenderWidth();
	uint32_t screen_height = Application::GetCurrentRenderHeight();

	static uint32_t num_rows = Mupfel::Application::Get().physics.collision_system->collision_grid.num_cells_y;
	static uint32_t num_columns = Mupfel::Application::Get().physics.collision_system->collision_grid.num_cells_x;
	static uint32_t cell_size = 1 << Mupfel::Application::Get().physics.collision_system->collision_grid.cell_size_pow;

	uint32_t pos_x = 0;
	uint32_t pos_y = 0;

	for (uint32_t y = 0; y < num_rows; y++)
	{

		if (pos_y > screen_height)
		{
			break;
		}

		for (uint32_t x = 0; x < num_columns; x++)
		{
			if (pos_x > screen_width)
			{
				break;
			}

			uint32_t cell_index = Mupfel::Application::Get().physics.collision_system->WorldtoCell({ pos_x, pos_y });

			if (Mupfel::Application::Get().physics.collision_system->collision_grid.cells[cell_index].count == 0)
			{
				RaylibDrawRect(pos_x, pos_y, cell_size, cell_size, 230, 41, 55, 255);

				uint32_t cell_count = Mupfel::Application::Get().physics.collision_system->collision_grid.cells[cell_index].count;

				std::string text = std::vformat("{}", std::make_format_args(cell_count));

				Text::RaylibDrawText(text.c_str(), pos_x, pos_y);
			}
			else
			{
				RaylibDrawRect(pos_x, pos_y, cell_size, cell_size, 0, 228, 48, 255);

				uint32_t cell_count = Mupfel::Application::Get().physics.collision_system->collision_grid.cells[cell_index].count;

				std::string text = std::vformat("{}", std::make_format_args(cell_count));

				Text::RaylibDrawText(text.c_str(), pos_x, pos_y);
			}

			pos_x += cell_size;
		}
		pos_x = 0;
		pos_y += cell_size;
	}
}

void Mupfel::DebugLayer::DrawEntityColliders()
{
	Registry& reg = Mupfel::Application::GetCurrentRegistry();

	auto spatial_view = reg.view<Mupfel::Transform, Mupfel::Collider>();

	for (auto [entity, t, collider] : spatial_view)
	{
		Mupfel::Circle::RayLibDrawCircleLines(t.pos_x, t.pos_y, collider.GetCircle(), 102, 191, 255, 255);
	}
}

void Mupfel::DebugLayer::DrawEntityVelocity()
{
	Registry& reg = Mupfel::Application::GetCurrentRegistry();


	auto movement_view = reg.view<Mupfel::Transform, Mupfel::Movement>();

	for (auto [entity, transform, movement] : movement_view)
	{
		if (fabs(movement.velocity_x) > 0.0f || fabs(movement.velocity_y) > 0.0f)
		{
			std::string text1 = std::vformat("{:.0f}{:.0f}", std::make_format_args(movement.velocity_x, movement.velocity_x));
			Mupfel::Text::RaylibDrawText(text1.c_str(), transform.pos_x, transform.pos_y, 15);
		}

	}
}

void Mupfel::DebugLayer::DrawEntityIndex()
{
	Registry& reg = Mupfel::Application::GetCurrentRegistry();


	auto movement_view = reg.view<Mupfel::Transform>();

	for (auto [entity, transform] : movement_view)
	{
		float idx = entity.Index();

		std::string text1 = std::vformat("{:.0f}", std::make_format_args(idx));
		Mupfel::Text::RaylibDrawText(text1.c_str(), transform.pos_x + 15, transform.pos_y, 15);

	}
}

void Mupfel::DebugLayer::DrawPerformanceMetrics()
{
	/* Print the Profiling Samples */
	const std::vector<ProfilingSample>& samples = Mupfel::Profiler::GetCurrentSamples();

	std::vector<ProfilingSample> local(samples.begin(), samples.end());

	if (!local.empty())
	{
		// Sortiere stabil nach Startzeit (aufsteigend)
		std::stable_sort(local.begin(), local.end(),
			[](auto const& a, auto const& b) {
				return a.id < b.id;
			});

		std::string t;
		uint32_t offset = 200;
		for (const auto& s : local)
		{
			std::string indent(s.depth * 2, ' ');
			double elapsed_ms = (s.end_time - s.start_time) * 1000.0f;
			t = std::vformat("{}{}: {:.0f}ms", std::make_format_args(indent, s.name, elapsed_ms));
			Text::RaylibDrawText(t.c_str(), 10, offset);
			offset += 20;
		}
	}
}

void Mupfel::DebugLayer::DrawDebugGUI()
{

	GuiCheckBox(Rectangle(anchor_x, anchor_y, 24, 24), "Show Performance", &show_perf);
	GuiCheckBox(Rectangle(anchor_x, anchor_y + 30, 24, 24), "Show Entity Colliders", &show_collider);
	GuiCheckBox(Rectangle(anchor_x, anchor_y + 60, 24, 24), "Show Grid", &show_grid);
	GuiCheckBox(Rectangle(anchor_x, anchor_y + 90, 24, 24), "Show Entity Velocity", &show_velocity);
	GuiCheckBox(Rectangle(anchor_x, anchor_y + 120, 24, 24), "Show Entity Index", &show_entity_index);
	static float scale = 1.0f;
	if (GuiSlider(Rectangle(anchor_x, anchor_y + 150, 100, 20), "", "Time Scale", &scale, 0.01f, 3.0f) != 0) {
		Application::SetTimeScale(scale);
	}
	if (GuiCheckBox(Rectangle(anchor_x, anchor_y + 180, 24, 24), "Enable Single Stepping", &single_stepping) != 0) {
		Application::TogglePhysicsSingleStep();
	}
}
